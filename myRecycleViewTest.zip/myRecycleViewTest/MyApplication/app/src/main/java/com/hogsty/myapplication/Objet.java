package com.hogsty.myapplication;

public class Objet {

    private String name;
    private String descriptif;
    private int imageId;

    public Objet(String name, String descriptif, int nomImage) {
        this.name = name;
        this.descriptif = descriptif;
        this.imageId = nomImage;
    }

    public String getName() {
        return name;
    }

    public String getDescriptif() {
        return descriptif;
    }

    public int getImageId() {
        return imageId;
    }
}
