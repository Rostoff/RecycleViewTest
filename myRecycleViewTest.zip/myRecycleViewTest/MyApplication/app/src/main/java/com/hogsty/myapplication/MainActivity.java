package com.hogsty.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView myRecyclerView;
    private List<Objet> mesObjet;
    private MyObjetAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myRecyclerView = (RecyclerView) findViewById(R.id.myRecyclerView);

        mesObjet = new ArrayList<>();

        mesObjet.add(new Objet("Objet1", "ça ne sert à rien", R.drawable.laptop));
        mesObjet.add(new Objet("Objet2", "ça ne sert à rien", R.drawable.keyboard));
        mesObjet.add(new Objet("Objet3", "ça ne sert à rien", R.drawable.mouse));

        myAdapter = new MyObjetAdapter(mesObjet);

        myRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        myRecyclerView.setAdapter(myAdapter);
    }
}
