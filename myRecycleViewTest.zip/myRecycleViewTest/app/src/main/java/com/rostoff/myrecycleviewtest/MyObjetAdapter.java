package com.rostoff.myrecycleviewtest;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

class MyObjetAdapter extends RecyclerView.Adapter<MyObjetAdapter.MyViewHolder> {

    List<Objet> mesObjets;

    public MyObjetAdapter(List<Objet> mesObjets) {
        this.mesObjets = mesObjets;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.objet_de_la_liste, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.display(mesObjets.get(position));
    }

    @Override
    public int getItemCount() {
        System.out.println(mesObjets.size());
        return mesObjets.size();
    }





    public class MyViewHolder extends RecyclerView.ViewHolder {

        //private ImageView mImage;
        private TextView mName;
        private TextView mdescriptif;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            //mImage = itemView.findViewById(R.id.image);
            mName = itemView.findViewById(R.id.name);
            mdescriptif = itemView.findViewById(R.id.descriptif);
        }

        void display(Objet objet){
            mName.setText(objet.getName());
            mdescriptif.setText(objet.getDescriptif());
            //mImage.setText()

        }
    }
}
