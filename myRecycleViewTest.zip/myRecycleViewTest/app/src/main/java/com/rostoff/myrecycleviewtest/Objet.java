package com.rostoff.myrecycleviewtest;

class Objet {

    private String name;
    private String descriptif;
    private String nomImage;

    public Objet(String name, String descriptif, String nomImage) {
        this.name = name;
        this.descriptif = descriptif;
        this.nomImage = nomImage;
    }

    public String getName() {
        return name;
    }

    public String getDescriptif() {
        return descriptif;
    }

    public String getNomImage() {
        return nomImage;
    }
}
